package com.speakingclock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpeakingclockApplicationTests {

	@Test
	void contextLoads() {
	}

}
