package com.speakingclock.controller;

//SpeakingClockControllerTest.java
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.speakingclock.service.SpeakingClockService;

import static org.mockito.ArgumentMatchers.anyString;

public class SpeakingClockControllerTest {

 @Mock
 private SpeakingClockService speakingClockService;

 @InjectMocks
 private SpeakingClockController speakingClockController;

 private final MockMvc mockMvc = MockMvcBuilders.standaloneSetup(speakingClockController).build();

 @Test
 public void testConvertTimeToWords() throws Exception {
     // Mock the service response
     Mockito.when(speakingClockService.convertTimeToWords(anyString())).thenReturn("It's twelve thirty");

     // Perform the request and verify the result
     mockMvc.perform(MockMvcRequestBuilders.get("/speaking-clock/convert/12:30")
             .contentType(MediaType.APPLICATION_JSON))
             .andExpect(MockMvcResultMatchers.status().isOk())
             .andExpect(MockMvcResultMatchers.content().string("It's twelve thirty"));
 }

 @Test
 public void testInvalidTimeFormat() throws Exception {
     // Mock the service to throw an IllegalArgumentException
     Mockito.when(speakingClockService.convertTimeToWords(anyString()))
             .thenThrow(new IllegalArgumentException("Invalid time format"));

     // Perform the request and verify the result
     mockMvc.perform(MockMvcRequestBuilders.get("/speaking-clock/convert/invalid-time")
             .contentType(MediaType.APPLICATION_JSON))
             .andExpect(MockMvcResultMatchers.status().isBadRequest())
             .andExpect(MockMvcResultMatchers.content().string("Invalid time format. Please use HH:mm"));
 }

 @Test
 public void testInternalServerError() throws Exception {
     // Mock the service to throw a generic exception
     Mockito.when(speakingClockService.convertTimeToWords(anyString()))
             .thenThrow(new RuntimeException("Something went wrong"));

     // Perform the request and verify the result
     mockMvc.perform(MockMvcRequestBuilders.get("/speaking-clock/convert/12:30")
             .contentType(MediaType.APPLICATION_JSON))
             .andExpect(MockMvcResultMatchers.status().isInternalServerError())
             .andExpect(MockMvcResultMatchers.content().string("Internal Server Error"));
 }
}
