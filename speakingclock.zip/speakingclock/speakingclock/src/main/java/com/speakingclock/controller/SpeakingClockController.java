package com.speakingclock.controller;



import com.speakingclock.service.SpeakingClockService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
@RestController
@RequestMapping("/speaking-clock")
public class SpeakingClockController {
	
@Autowired
 private  SpeakingClockService speakingClockService;

 
 

 @GetMapping("/convert/{time}")
 public ResponseEntity<String> convertTimeToWords(@PathVariable String time) {
     try {
         String result = speakingClockService.convertTimeToWords(time);
         return ResponseEntity.ok(result);
     } catch (IllegalArgumentException e) {
         
         return ResponseEntity.badRequest().body("Invalid time format. Please use HH:mm");
     } catch (Exception e) {
         
         return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error converting time to words");
     }
 }


 @ExceptionHandler(IllegalArgumentException.class)
 @ResponseStatus(HttpStatus.BAD_REQUEST)
 public ResponseEntity<String> handleIllegalArgumentException(IllegalArgumentException e) {
     return ResponseEntity.badRequest().body(e.getMessage());
 }

 
 @ExceptionHandler(Exception.class)
 @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
 public ResponseEntity<String> handleException(Exception e) {
     return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Internal Server Error");
 }
}
