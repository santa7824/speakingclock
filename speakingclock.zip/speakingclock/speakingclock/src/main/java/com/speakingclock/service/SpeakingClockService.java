package com.speakingclock.service;

public interface SpeakingClockService {
	String convertTimeToWords(String time);
}
