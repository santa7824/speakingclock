package com.speakingclock.service;



import org.springframework.stereotype.Service;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

@Service
public class SpeakingClockServiceImpl implements SpeakingClockService {

 private final Map<Integer, String> numbersToWords = new HashMap<>();

 public SpeakingClockServiceImpl() {
     initializeNumberToWords();
 }

 private void initializeNumberToWords() {
	    numbersToWords.put(0, "zero");
	    numbersToWords.put(1, "one");
	    numbersToWords.put(2, "two");
	    numbersToWords.put(3, "three");
	    numbersToWords.put(4, "four");
	    numbersToWords.put(5, "five");
	    numbersToWords.put(6, "six");
	    numbersToWords.put(7, "seven");
	    numbersToWords.put(8, "eight");
	    numbersToWords.put(9, "nine");
	    numbersToWords.put(10, "ten");
	    numbersToWords.put(11, "eleven");
	    numbersToWords.put(12, "twelve");
	    numbersToWords.put(13, "thirteen");
	    numbersToWords.put(14, "fourteen");
	    numbersToWords.put(15, "fifteen");
	    numbersToWords.put(16, "sixteen");
	    numbersToWords.put(17, "seventeen");
	    numbersToWords.put(18, "eighteen");
	    numbersToWords.put(19, "nineteen");
	    numbersToWords.put(20, "twenty");
	    numbersToWords.put(30, "thirty");
	    numbersToWords.put(40, "forty");
	    numbersToWords.put(50, "fifty");
	    
	    for (int i = 21; i <= 59; i++) {
	        if (i % 10 != 0) {
	            int tens = i / 10 * 10;
	            int ones = i % 10;
	            numbersToWords.put(i, numbersToWords.get(tens) + " " + numbersToWords.get(ones));
	        }
	    }
	}


 @Override
 public String convertTimeToWords(String time) {
	 //DateTimeFormatter dtf = DateTimeFormatter.ofPattern("hh:mm");
     LocalTime localTime = LocalTime.parse(time);

     int hour = localTime.getHour();
     int minute = localTime.getMinute();

     if (hour == 0 && minute == 0) {
         return "It's Midnight";
     } else if (hour == 12 && minute == 0) {
         return "It's Midday";
     } else {
         String hourWords = numbersToWords.get(hour);
         String minuteWords = numbersToWords.get(minute);


         return String.format("It's %s %s %s", hourWords, (minute > 0 ? minuteWords : ""), (minute > 0 ? "minutes" : ""));
     }
 }
}
